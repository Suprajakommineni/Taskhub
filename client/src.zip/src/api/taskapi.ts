import axios from "axios";

const taskApi = axios.create({
  baseURL: `${import.meta.env.VITE_API_URL}/api/tasks`,
});

taskApi.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

export default taskApi;